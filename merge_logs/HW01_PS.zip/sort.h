#ifndef SORT_H
#define SORT_H

loglist_t* mergeLists(loglist_t* result_list, loglist_t* inlist);
loglist_t* sortList(loglist_t* inlist);

#endif
